frutas = ['laranja', 'banana', 'abacaxi', 'maçã', 'uva', 'morango', 
'manga', 'kiwi', 'pera', 'melancia']
frutas.sort()
print(frutas)  