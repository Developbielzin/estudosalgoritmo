try:
    resultado = 10 / 0
except ZeroDivisionError:
    print("Não é possível dividir por zero.")
else:
    print("Nenhum erro ocorreu.")
