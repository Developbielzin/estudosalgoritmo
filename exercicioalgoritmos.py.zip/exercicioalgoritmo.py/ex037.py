def operadores_logicos(a, b):
    resultado_and = a and b
    resultado_or = a or b
    resultado_not_a = not a
    resultado_not_b = not b
    return resultado_and, resultado_or, resultado_not_a, resultado_not_b

# Exemplo de uso:
a = True
b = False
resultado = operadores_logicos(a, b)
print(f"AND: {resultado[0]}")
print(f"OR: {resultado[1]}")
print(f"NOT a: {resultado[2]}")
print(f"NOT b: {resultado[3]}")
