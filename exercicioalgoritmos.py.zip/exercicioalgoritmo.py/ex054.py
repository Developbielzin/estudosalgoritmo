try:
    a = int(input('numerador: '))
    b = int(input('denominador: '))
    r = a / b

    print(r)
except: 
    print('deu erro! estude mais que você consegue')


