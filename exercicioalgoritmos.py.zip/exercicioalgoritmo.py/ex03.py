frase = "a melhor aula de python do youtube"


print(frase.upper())
print(frase.__len__())