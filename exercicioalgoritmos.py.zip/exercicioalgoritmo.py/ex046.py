def busca_sequencial(x, seq):
    for i in range(len(seq)):
        if seq[i] == x:
            return i
    return -1  # Retorna -1 se o elemento não for encontrado

# Criando a lista de 1 a 8
minha_lista = [1, 2, 3, 4, 5, 6, 7, 8]

# Buscando o número 4
posicao = busca_sequencial(6, minha_lista)

if posicao != -1:
    print(f"O número 6 está na posição {posicao}.")
else:
    print("O número 6 não está na lista.")



