def soma():
    a = int(input('digite um número?'))
    b = int(input('digite um número?'))
    s = a + b
    print(f' a soma dos números é {s}')


soma()
