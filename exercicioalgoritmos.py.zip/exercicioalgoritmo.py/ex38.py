# Solicita que o usuário digite uma sequência de números separados por espaço
entrada = input("Digite uma sequência de números separados por espaço: ")

# Divide a entrada em uma lista de strings
numeros_str = entrada.split()

# Converte cada string para um número inteiro
numeros = [int(numero) for numero in numeros_str]

# Exibe a lista de números
print("Lista de números:", numeros)
