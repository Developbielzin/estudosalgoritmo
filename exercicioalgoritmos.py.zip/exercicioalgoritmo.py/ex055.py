try:
    valor = int(input("Digite um número inteiro: "))
    resultado = 10 / valor
    print("O resultado é:", resultado)
except ValueError:
    print("Você digitou um valor inválido. Digite um número inteiro.")
else:
    print("Nenhum erro ocorreu.")
