numero = int(input('digite um numero:'))
unidade = numero // 1 % 10
dezena = numero // 10 % 10 
centena = numero // 100 % 10
milhar = numero // 1000 % 10
print(f'a unidade é {unidade}')
print(f' a dezena é {dezena}')
print(f' a centena é {centena}')
print(f' o milhar é {milhar}')

