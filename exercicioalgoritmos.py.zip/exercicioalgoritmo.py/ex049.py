def soma(a, b):
    s = a + b
    print(s)

soma(1, 1)
soma(2, 2)