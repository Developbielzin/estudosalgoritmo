numero = int(input('digite um numero:'))
if numero % 2 == 0:
    print('ele é par')
else:
    print('ele é impar')