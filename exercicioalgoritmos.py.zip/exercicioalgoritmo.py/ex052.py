import random

def gerar_numero_aleatorio(minimo, maximo):
    return random.randint(minimo, maximo)

# Exemplo de uso:
numero_aleatorio = gerar_numero_aleatorio(10, 20)
print(f"Número aleatório entre 10 e 20: {numero_aleatorio}")
