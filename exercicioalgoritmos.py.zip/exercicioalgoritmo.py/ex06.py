
cid = input('Qual é a sua cidade? ').strip()
print(cid[:5].upper() == 'SANTO')
