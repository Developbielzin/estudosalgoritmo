lista_frutas = ['maça', 'banana', 'manga', 'maracuja']
for frutas in lista_frutas:
    print(frutas.capitalize())