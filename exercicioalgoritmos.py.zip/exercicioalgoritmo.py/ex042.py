def achar():
    quantidade = int(input(' quantos números você quer digitar?'))
    numeros = []
    for i in range(quantidade):
        n = int(input(f' digite o número:  {i+1}  '))
        numeros.append(n)
    numeros.sort()
    maior_elemento = numeros[-1]
    print(f'o maior elemento dessa lista é {maior_elemento}')
achar()



