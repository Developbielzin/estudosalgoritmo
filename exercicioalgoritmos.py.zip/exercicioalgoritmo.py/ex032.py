dataano = int(input('digite qualquer tipo de ano por favor'))
if dataano % 4 == 0 and dataano % 100 != 0:
    print(f' {dataano} é uma ano bissexto')
else:
    print(f'{dataano} não é um ano bissexto')
