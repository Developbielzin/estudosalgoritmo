def comprimentoMaior(string1, string2):
    if len(string1) > len(string2):
        return True
    else:
        return False

# Exemplo de uso:
string1 = "casa"
string2 = "apartamento"
resultado = comprimentoMaior(string1, string2)
print(resultado)  # Saída será True, pois "casa" tem comprimento maior que "apartamento"
