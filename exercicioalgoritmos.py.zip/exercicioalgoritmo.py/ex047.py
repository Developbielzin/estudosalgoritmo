def mostra():
    print('-' * 30)

mostra()
print('aula de python')
mostra()
mostra()
print('revendo funções')
mostra()