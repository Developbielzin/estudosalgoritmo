def contador(y, x, z):
    c = y
    while c <= x:
        print(f'{c}', end='...')
        c += z
        print('fim')

contador(2, 20, 2)