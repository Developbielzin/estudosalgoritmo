nome = input('Qual é o seu nome completo? ').strip()
print(f'Tem "SILVA" no seu nome? {"SILVA" in nome.upper()}')
