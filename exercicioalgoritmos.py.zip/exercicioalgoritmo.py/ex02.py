def pesquisa_binaria(lista, item):
    baixo = 0
    alto = len(lista) - 1
    while baixo <= alto:
        meio = (baixo + alto) // 2
        chute = lista[meio]
        if chute == item:
            return meio
        if chute < item:
            baixo = meio + 1
        else:
            alto = meio - 1
            
    return None  # Se o item não for encontrado

lista = [1, 2, 3, 4]
resultado = pesquisa_binaria(lista, 3)
if resultado is not None:
    print(f"O item {lista[resultado]} foi encontrado na posição {resultado}.")
else:
    print("O item não foi encontrado na lista.")
