listanum = [2, 5, 7, 9, 12, 20, 22]
r = 0 # criar ma lista de números e uma variável para começar a soma entre eles
for i in listanum:  # depois criar uma vvariável dentro de for i in range para definir o elemento da lista e depois criar a soma ambaixo de for
    r += i


print(f' a soma do valores da lista é {r}')


