numeros = []
for count in range(10):
    numeros += [count]
print(numeros)
