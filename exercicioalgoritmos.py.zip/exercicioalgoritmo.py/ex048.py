def mostra(msg):
    print('-' * 100)
    print(msg)
    print('-' * 100)


mostra('aula da desgrama de python')
mostra('programação é dificil pra desgrama')
mostra('sua as amigas eu vou pegar e laialaiaaaa')
mostra('me deu onda o teu sorriso, me da onda')


