km = int(input('digite quantos km você quer fazer:'))
r1 = km * 0.50
r2 = km * 0.45
if km <= 200:
    print(f'o custo de sua viagem séra de {r1}')
elif km > 200:
    print(f'o custo de sua viagem séra de {r2} ')