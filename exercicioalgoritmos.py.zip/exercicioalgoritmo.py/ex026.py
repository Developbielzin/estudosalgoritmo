def contar_letra_a(frase):
    # Transforma a frase em minúsculas para facilitar a contagem
    frase = frase.lower()
    
    # Conta a quantidade de vezes que a letra "a" aparece
    quantidade_a = frase.count("a")
    
    # Encontra a posição da primeira ocorrência da letra "a"
    primeira_posicao = frase.find("a") + 1  # Adicionamos 1 para exibir a posição humana (começando em 1)
    
    # Encontra a posição da última ocorrência da letra "a"
    ultima_posicao = frase.rfind("a") + 1  # Adicionamos 1 para exibir a posição humana (começando em 1)
    
    return quantidade_a, primeira_posicao, ultima_posicao

# Lê a frase do usuário
frase_usuario = input("Digite uma frase: ")

# Chama a função e exibe os resultados
quantidade, primeira, ultima = contar_letra_a(frase_usuario)
print(f"A letra 'a' aparece {quantidade} vezes.")
print(f"Primeira ocorrência na posição: {primeira}")
print(f"Última ocorrência na posição: {ultima}")
