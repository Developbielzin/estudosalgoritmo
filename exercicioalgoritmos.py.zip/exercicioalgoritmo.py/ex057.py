with open('arquivo.txt', 'r') as arquivo:
    print(arquivo.read())