# Exemplo: Encontrando números primos em um intervalo
def eh_primo(numero):
    if numero < 2:
        return False
    for i in range(2, int(numero**0.5) + 1):
        if numero % i == 0:
            return False
    return True

def encontrar_primos(no_intervalo):
    primos = []
    for num in range(2, no_intervalo):
        if eh_primo(num):
            primos.append(num)
    return primos

intervalo = 100
primos_encontrados = encontrar_primos(intervalo)
print(f"Números primos no intervalo de 2 a {intervalo}:")
print(primos_encontrados)
