def area():
    print('controle de terreno')
    print('-' * 90)
    l = int(input('largura (m): '))
    d = int(input('comprimento (m): '))
    r = l * d
    
    print(f' a área do terreno é de {r}m²')
area()