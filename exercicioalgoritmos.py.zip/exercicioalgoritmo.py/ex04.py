nome = input('Digite o seu nome completo: ')
print(nome.upper())
print(nome.lower())
print(f'O seu nome tem um total de {len(nome) - nome.count(" ")} letras')

dividido = nome.split()
print(f'O primeiro nome tem {len(dividido[0])} caracteres')
