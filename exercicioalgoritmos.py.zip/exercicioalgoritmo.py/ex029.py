vel = int(input(' qual foi a velocidade do carro?'))
multa = (vel - 80) * 7
if vel <= 80:
    print('tudo bem, esta na velocidade correta')
elif vel > 80:
    print(f'você recebera uma multa de {multa} por ultrapassar a velocidade')