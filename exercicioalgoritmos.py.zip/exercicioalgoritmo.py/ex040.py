quantidade = int(input(' quantos números você quer digitar?'))
numeros = []
for i in range(quantidade):
    n = int(input(f' digite o número {i+1}:'))
    numeros.append(n)
numeros.sort()
print('os numeros são:', numeros) 