# Lê o nome completo da pessoa
nome_completo = input("Digite seu nome completo: ")

# Divide o nome em palavras
partes_do_nome = nome_completo.split()

# Exibe o primeiro nome
primeiro_nome = partes_do_nome[0]
print(f"Primeiro nome: {primeiro_nome}")

# Exibe o último nome
ultimo_nome = partes_do_nome[-1]
print(f"Último nome: {ultimo_nome}")
 