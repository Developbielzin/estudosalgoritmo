with open('arquivo.txt', 'w') as arquivo:
    arquivo.write('escrevendo no arquivo')