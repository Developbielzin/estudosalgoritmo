 #Escreva uma função que receba uma lista ordenada como parâmetro e 
#retorne uma nova lista contendo apenas os números pares, e outra lista 
#com os números primos da lista original.  
#Considere: Lista [1,2,3, ... , 100000] 
def n_primos(num):
    if num < 2:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True



def separate_even_and_prime_numbers(start, end):
    pares = []
    primos = []
    for num in range(start, end + 1):
        if num % 2 == 0:
            pares.append(num)
        elif n_primos(num):
            primos.append(num)
    return pares, primos

# Testando com a lista de 20 a 100
pares, primos = separate_even_and_prime_numbers(20, 100)
print("Números pares:", pares)
print("Números primos:", primos)
