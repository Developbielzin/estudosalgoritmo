# Pedir ao usuário para inserir a quantidade de números que deseja digitar
quantidade = int(input("Quantos números você deseja inserir? "))

# Inicializar uma lista vazia para armazenar os números
numeros = []

# Loop para solicitar os números e adicioná-los à lista
for i in range(quantidade):
    numero = int(input(f"Digite o número {i+1}: "))
    numeros.append(numero)

# Exibir os números armazenados na lista
print("Os números que você digitou são:", numeros)
