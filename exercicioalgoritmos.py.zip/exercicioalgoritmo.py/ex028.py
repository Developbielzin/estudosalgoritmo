import random
nunale = random.randint(1,5)
numero = int(input('tente acerta o numero que eu escolhi de 1 á 5:'))
if numero == nunale:
    print('você ganhou!')
else:
    print('o computador ganhou!')